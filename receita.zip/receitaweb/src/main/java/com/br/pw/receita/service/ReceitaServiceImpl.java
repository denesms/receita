package com.br.pw.receita.service;

import java.util.List;

import com.br.pw.receita.dao.ReceitaDao;
import com.br.pw.receita.domain.Receita;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service @Transactional(readOnly = false)
public class ReceitaServiceImpl implements ReceitaService {
	
	@Autowired
	private ReceitaDao dao;

	@Override
	public void salvar(Receita receita) {
		dao.save(receita);
	}

	@Override
	public void editar(Receita receita) {
		dao.update(receita);
	}

	@Override
	public void excluir(Long id) {
		dao.delete(id);		
	}

	@Override @Transactional(readOnly = true)
	public Receita buscarPorId(Long id) {
		
		return dao.findById(id);
	}

	@Override @Transactional(readOnly = true)
	public List<Receita> buscarTodos() {
		
		return dao.findAll();
	}

}
