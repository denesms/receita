package com.br.pw.receita.web.controller;

import com.br.pw.receita.domain.Receita;
import com.br.pw.receita.service.ReceitaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@RequestMapping("/receitas")
public class ReceitaController {

	@Autowired
	private ReceitaService service;

	@GetMapping("/cadastrar")
	public String cadastrar(Receita receita) {
		return "/receita/cadastro";
	}
	
	@GetMapping("/listar")
	public String listar(ModelMap model) {
		model.addAttribute("receitas", service.buscarTodos());
		return "/receita/lista";
	}


	@GetMapping("/visualizar/{id}")
	public String listarporid(@PathVariable("id") Long id ,ModelMap model) {
		model.addAttribute("receita", service.buscarPorId(id));
		return "/receita/visualiza";
	}

	@PostMapping("/salvar")
	public String salvar(@Valid Receita receita, BindingResult result, RedirectAttributes attr) {

		if (result.hasErrors()){
			return "receita/cadastro";
		}
		service.salvar(receita);
		attr.addFlashAttribute("success", "Receita inserida com sucesso.");
		return "redirect:/receitas/cadastrar";
	}

	@GetMapping("/editar/{id}")
	public String preEditar(@PathVariable("id") Long id, ModelMap model) {
		model.addAttribute("receita", service.buscarPorId(id));
		return "/receita/cadastro";
	}

	@PostMapping("/editar")
	public String editar(@Valid Receita receita,BindingResult result, RedirectAttributes attr) {
		if (result.hasErrors()){
			return "receita/cadastro";
		}
		service.editar(receita);
		attr.addFlashAttribute("success", "Receita editada com sucesso.");
		return "redirect:/receitas/cadastrar";
	}

	@GetMapping("/excluir/{id}")
	public String excluir(@PathVariable("id") Long id, ModelMap model) {

			service.excluir(id);
			model.addAttribute("success", "Receita excluída com sucesso.");
			return listar(model);
	}


}
