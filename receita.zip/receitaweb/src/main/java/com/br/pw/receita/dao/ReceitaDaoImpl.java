package com.br.pw.receita.dao;

import com.br.pw.receita.domain.Receita;
import org.springframework.stereotype.Repository;

@Repository
public class ReceitaDaoImpl extends AbstractDao<Receita, Long> implements ReceitaDao{
}
