package com.br.pw.receita.service;

import java.util.List;

import com.br.pw.receita.domain.Receita;

public interface ReceitaService {

	void salvar(Receita receita);
	
	void editar(Receita receita);
	
	void excluir(Long id);
	
	Receita buscarPorId(Long id);
	
	List<Receita> buscarTodos();
}
