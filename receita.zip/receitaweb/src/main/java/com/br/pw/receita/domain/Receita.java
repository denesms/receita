package com.br.pw.receita.domain;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

//bean validation spring boot
@Entity
@Table(name = "RECEITAS")
public class Receita extends AbstractEntity<Long> {

    @Size(max = 60, message = "O nome do cargo deve conter no máximo 60 caracteres.")
    @NotBlank(message = "O nome da receita é obrigatório.")
    @Column(name = "nome", nullable = false)
    private String nome;

    @NotNull(message = "Selecione o um tipo.")
    @Column(name = "tipo", nullable = false)
    private String tipo;

    @NotBlank(message = "Os ingredientes são obrigatórios.")
    @Column(name = "ingredientes", nullable = false)
    private String ingredientes;

    @NotBlank(message = "O modo de preparo e obrigatório.")
    @Column(name = "mpreparo", nullable = false)
    private String mpreparo;

    @Column(name = "observacao", nullable = false)
    private String observacao;


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public String getMpreparo() {
        return mpreparo;
    }

    public void setMpreparo(String mpreparo) {
        this.mpreparo = mpreparo;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
}
