package com.br.pw.receita.dao;

import com.br.pw.receita.domain.Receita;

import java.util.List;

public interface ReceitaDao {

    void save(Receita receita);

    void update(Receita receita);

    void delete(Long id);

    Receita findById(Long id);

    List<Receita> findAll();

}
